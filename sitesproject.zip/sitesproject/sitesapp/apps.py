from django.apps import AppConfig


class SitesappConfig(AppConfig):
    name = 'sitesapp'
